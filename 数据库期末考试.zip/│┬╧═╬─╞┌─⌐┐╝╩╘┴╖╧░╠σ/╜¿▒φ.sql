create table Student
(
	Sno int primary key,
	Sname char(8),
	Ssex Char(4),
	Sage int ,
	Sdept Char(4)
	
);
create table Course 
(
	Cno int primary key,
	Cname Char(10),
	Ccredit int
);
create table SC
(
	Sno int ,
	Cno int,
	Grade int,
	primary key (Sno,Cno),
	foreign key (Sno)references Student(Sno),
	foreign key (Cno)references Course(Cno),
);