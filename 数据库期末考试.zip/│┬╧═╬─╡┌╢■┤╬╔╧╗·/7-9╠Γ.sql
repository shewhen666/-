Select Sno, Degree 
from Teacher,Score,Course
where Course.Cno =Score.Cno and Course. Tno = Teacher.Tno and Tname = '����';
select Tname 
From Teacher,Course
where Course. Tno = Teacher.Tno and Cno =(
	select Cno
	from Score
	group by Score.Cno
	having COUNT(Sno)>5
);
select Tname, Cname, Sname ,Degree 
from Teacher,Score,Course,Student 
where Course.Cno =Score.Cno and Course. Tno = Teacher.Tno and Student.Sno = Score.Sno 
and Depart = '�����ϵ';

--select Cno ,Sno ,Degree
--from Score
--group by Sno
--having Cno ='3-105' and Degree >
--(
--	select Degree 
--	where Cno ='3-245'
--)
--order by (Degree) DESC;

