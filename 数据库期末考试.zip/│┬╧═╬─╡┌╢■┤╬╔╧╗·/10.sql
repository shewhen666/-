select t1.Cno,t1.Sno,t1.Degree
from Score t1 
where Sno = (
	SELECT t2.Sno
	from Score t2 
	where t2.Sno=t1.Sno and t2.Cno = '3-105' and t1.Cno ='3-245' and t2.Degree>t1.Degree 
)
order by Degree ASC;