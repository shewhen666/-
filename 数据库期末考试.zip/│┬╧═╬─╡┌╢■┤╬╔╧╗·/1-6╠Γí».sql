select Sname ,Ssex,Class
from Student;
Select distinct Depart
from Teacher;
select *
from Score
where Degree between 60 and 80;
Select *
from Student 
where Class = '95031' OR Ssex = 'Ů' ;

select AVG(Degree)
from Score 
group by Cno 
having COUNT(Sno)>5 and Cno like '3%';

select Sno,Degree 
from Score
where Cno = '3-105' and Degree >( 
select Degree 
from Score 
where Cno = '3-105' and Sno = '109'
);