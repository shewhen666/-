create table Student
(
	Sno int primary key ,
	Sname char(8) unique,
	Ssex Char(8),
	Sbirthday Char(20),
	Class int,
);
create table Course
(
	Cno char(8) primary key,
	Cname char(20),
	Tno int
);
create table Score
(
	Sno int,
	Cno char(8),
	Degree char (8),
	primary key (Sno,Cno),
);
create table Teacher
(
	Tno int,
	Tname char(8),
	Tsex char(8),
	Tbirthday char(20),
	Prof char(8),
	Depart char(20),
);