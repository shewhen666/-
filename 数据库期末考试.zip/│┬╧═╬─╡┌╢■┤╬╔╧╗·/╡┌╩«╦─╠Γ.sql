create view �༶95033 
as
select *
from Student 
where Class ='95033';