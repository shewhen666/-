SELECT SNAME,AGE
from Student,Dept
where Student.DEPTNO = Dept.DEPTNO and DNAME = '��Ϣ' and SEX = 'Ů' and AGE <22;