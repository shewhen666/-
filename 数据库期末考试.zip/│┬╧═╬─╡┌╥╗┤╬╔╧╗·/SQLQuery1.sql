create table Student
(
	SNO int primary key ,
	SNAME char(8) unique,
	SEX CHar(2),
	
	DEPTNO int,

);
alter table Student
add AGE int ;
create table Course
(
	CNO int primary key ,
	CNAME char(20) not null,
	TNO int,
	CREDIT int,

);
create table SC
(
	SNO int ,
	CNO int ,
	GRADE int,
	primary key (SNO,CNO),
);

