SELECT *
FROM Student;
SELECT SNAME
FROm Student
where SEX ='Ů';
Select * 
from SC
where GRADE between 80 and 90 
order by GRADE desc;
select DEPTNO,  COUNT(DEPTNO) Sum_of_DEP
from Student
Group by DEPTNO;

