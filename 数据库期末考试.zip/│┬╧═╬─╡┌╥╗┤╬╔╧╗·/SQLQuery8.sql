UPDATE SC 
SET GRADE = GRADE +2
WHERE SC.CNO in 
	(
		select SC.CNO 
		from Course
		where SC.CNO =Course.CNO and CNAME ='���ݽṹ'AND TNO = 101
	)
