select SNAME 
from Student
where SNO in
(
	select SNO
	from SC,Course
	where Student.SNO=SC.SNO and SC.CNO=Course.CNO
	group by SNO
	having SUM(CREDIT)<10
);


--select SNAME,GRADE
--from SC,Student
--where Student.SNO=SC.SNO 
--and GRADE in(
--				select max(GRADE)
--				from SC
--				group by CNO
--				)
--group by CNO;

--group by CNO
--having GRADE=max(GRADE);
--Student.SNO=SC.SNO and SC.CNO=Course.CNO
--group by SNAME
--having SUM(CREDIT)<10; 

/*********************************************/
--select SC.CNO,SNAME ,MAX (GRADE),
--from Student,SC
--where Student.SNO=SC.SNO
--group by SC.CNO
--having GRADE = MAX(GRADE);

