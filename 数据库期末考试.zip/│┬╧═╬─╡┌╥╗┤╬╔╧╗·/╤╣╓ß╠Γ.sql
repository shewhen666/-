select SNAME, t1.SNO,t1.CNO,t1.GRADE
from SC t1 ,Student
where t1.SNO = Student.SNO and t1.GRADE = 
(
	select max(t2.GRADE)
	from SC t2
	where t2.CNO = t1.CNO
	group by t2.CNO
)
